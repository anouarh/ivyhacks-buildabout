package com.buildabout.backendba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendBaApplicationTests {

	@Test
	void contextLoads() {
	}

}
