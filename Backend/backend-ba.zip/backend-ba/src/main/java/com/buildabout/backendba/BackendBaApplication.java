package com.buildabout.backendba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendBaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendBaApplication.class, args);
	}

}
